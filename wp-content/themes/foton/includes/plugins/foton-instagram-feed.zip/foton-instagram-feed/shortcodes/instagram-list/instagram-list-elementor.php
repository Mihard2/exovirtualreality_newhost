<?php

function foton_elementor_instagram_list_set_icon() {
	$path = realpath(__DIR__);
	$path = str_replace('\\','/', $path);
	$icon_path = '../' . strstr($path, 'wp-content') . '/assets/img/dashboard_icon.png';
	
	$style = '.foton-elementor-custom-icon.foton-elementor-instagram-list{
						background-image: url("' . $icon_path . '") !important;
					}';
	
	wp_add_inline_style( 'foton-mikado-elementor-icons', $style);
}

add_action( 'elementor/editor/before_enqueue_scripts', 'foton_elementor_instagram_list_set_icon' );

class ElementorInstagramList extends \Elementor\Widget_Base {
	
	public function get_name() {
		return 'mkdf_instagram_list';
	}
	
	public function get_title() {
		return esc_html__( 'Instagram List', 'foton-instagram-feed' );
	}
	
	public function get_icon() {
		return 'foton-elementor-custom-icon foton-elementor-instagram-list';
	}
	
	public function get_categories() {
		return [ 'mikado' ];
	}
	
	protected function _register_controls() {
		$this->start_controls_section(
			'general',
			[
				'label' => esc_html__( 'General', 'foton-instagram-feed' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'number_of_columns',
			[
				'label'   => esc_html__( 'Number of Columns', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_number_of_columns_array(false, array('one', 'six'))
			]
		);
		
		$this->add_control(
			'space_between_columns',
			[
				'label'   => esc_html__( 'Space Between Columns', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_space_between_items_array(),
			]
		);
		
		$this->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'gallery'  => esc_html__( 'Gallery', 'foton-core' ),
//					'carousel' => esc_html__( 'Carousel', 'foton-core' )
				],
			]
		);
		
		$this->add_control(
			'number_of_photos',
			[
				'label' => esc_html__( 'Number of Photos', 'foton-twitter-feed' ),
				'type'  => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		$this->add_control(
			'transient_time',
			[
				'label' => esc_html__( 'Images Cache Time', 'foton-twitter-feed' ),
				'type'  => \Elementor\Controls_Manager::TEXT,
			]
		);
		
		$this->add_control(
			'show_instagram_icon',
			[
				'label'   => esc_html__( 'Show Instagram Icon', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_yes_no_select_array( false )
			]
		);
		
		$this->add_control(
			'image_size',
			[
				'label'   => esc_html__( 'Image Size', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'thumbnail'           => esc_html__( 'Small', 'foton-instagram-feed' ),
					'low_resolution'      => esc_html__( 'Medium', 'foton-instagram-feed' ),
					'standard_resolution' => esc_html__( 'Large', 'foton-instagram-feed' )
				],
			]
		);
		
		$this->add_control(
			'slider_loop',
			[
				'label'   => esc_html__( 'Enable Slider Loop', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_yes_no_select_array( false, true )
			]
		);
		
		$this->add_control(
			'slider_autoplay',
			[
				'label'   => esc_html__( 'Enable Slider Autoplay', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_yes_no_select_array( false, true )
			]
		);
		
		$this->add_control(
			'slider_speed',
			[
				'label'       => esc_html__( 'Slide Duration', 'foton-instagram-feed' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'options'     => foton_mikado_get_yes_no_select_array( false, true ),
				'description' => esc_html__( 'Default value is 5000 (ms)', 'foton-instagram-feed' ),
			]
		);
		
		$this->add_control(
			'slider_speed_animation',
			[
				'label'       => esc_html__( 'Slide Animation Duration', 'foton-instagram-feed' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'options'     => foton_mikado_get_yes_no_select_array( false, true ),
				'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'foton-instagram-feed' ),
			]
		);
		
		$this->add_control(
			'slider_navigation',
			[
				'label'   => esc_html__( 'Enable Slider Navigation Arrows', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_yes_no_select_array( false, true )
			]
		);
		
		$this->add_control(
			'slider_pagination',
			[
				'label'   => esc_html__( 'Enable Slider Pagination', 'foton-instagram-feed' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => foton_mikado_get_yes_no_select_array( false, false )
			]
		);
	}
	
	public function render() {
		$params = $this->get_settings_for_display();
		
		$params['holder_classes']   = $this->getHolderClasses( $params );
		$params['carousel_classes'] = $this->getCarouselClasses( $params );
		
		$instagram_api           = new \FotonInstagramApi();
		$params['instagram_api'] = $instagram_api;
		
		$images_array = $instagram_api->getImages( $params['number_of_photos'], array(
			'use_transients' => true,
			'transient_name' => rand( 0, 1000 ),
			'transient_time' => $params['transient_time']
		) );
		
		$params['images_array'] = $images_array;
		$params['data_attr']    = $this->getSliderData( $params );
		
		//Get HTML from template based on type of team
		echo foton_instagram_get_shortcode_module_template_part( 'templates/holder', 'instagram-list', '', $params );
	}
	
	public function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = $this->getColumnNumberClass( $params['number_of_columns'] );
		$holderClasses[] = ! empty( $params['space_between_columns'] ) ? 'mkdf-' . $params['space_between_columns'] . '-space' : 'mkdf-il-normal-space';
		
		return implode( ' ', $holderClasses );
	}
	
	public function getCarouselClasses( $params ) {
		$carouselClasses = array();
		
		if ( $params['type'] === 'carousel' ) {
			$carouselClasses = 'mkdf-instagram-carousel mkdf-owl-slider';
			
		} else if ( $params['type'] == 'gallery' ) {
			$carouselClasses = 'mkdf-instagram-gallery';
		}
		
		return $carouselClasses;
	}
	
	public function getColumnNumberClass( $params ) {
		switch ( $params ) {
			case 1:
				$classes = 'mkdf-il-one-column';
				break;
			case 2:
				$classes = 'mkdf-il-two-columns';
				break;
			case 3:
				$classes = 'mkdf-il-three-columns';
				break;
			case 4:
				$classes = 'mkdf-il-four-columns';
				break;
			case 5:
				$classes = 'mkdf-il-five-columns';
				break;
			default:
				$classes = 'mkdf-il-three-columns';
				break;
		}
		
		return $classes;
	}
	
	private function getSliderData( $params ) {
		$slider_data = array();
		
		$slider_data['data-number-of-items']        = $params['number_of_columns'];
		$slider_data['data-enable-loop']            = ! empty( $params['slider_loop'] ) ? $params['slider_loop'] : '';
		$slider_data['data-enable-autoplay']        = ! empty( $params['slider_autoplay'] ) ? $params['slider_autoplay'] : '';
		$slider_data['data-slider-speed']           = ! empty( $params['slider_speed'] ) ? $params['slider_speed'] : '5000';
		$slider_data['data-slider-speed-animation'] = ! empty( $params['slider_speed_animation'] ) ? $params['slider_speed_animation'] : '600';
		$slider_data['data-enable-navigation']      = ! empty( $params['slider_navigation'] ) ? $params['slider_navigation'] : '';
		$slider_data['data-enable-pagination']      = ! empty( $params['slider_pagination'] ) ? $params['slider_pagination'] : '';
		
		return $slider_data;
	}
}

\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new ElementorInstagramList() );