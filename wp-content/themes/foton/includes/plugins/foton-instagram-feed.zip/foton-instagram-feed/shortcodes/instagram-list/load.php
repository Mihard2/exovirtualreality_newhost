<?php

include_once FOTON_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/functions.php';
include_once FOTON_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list.php';

if ( foton_instagram_is_elementor_installed() ) {
	include_once FOTON_INSTAGRAM_SHORTCODES_PATH . '/instagram-list/instagram-list-elementor.php';
}