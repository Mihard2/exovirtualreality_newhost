<?php if(foton_mikado_show_comments()) : ?>
    <?php comments_template('', true); ?>
<?php endif; ?>