<?php

include_once FOTON_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once FOTON_CORE_CPT_PATH . '/testimonials/helper-functions.php';