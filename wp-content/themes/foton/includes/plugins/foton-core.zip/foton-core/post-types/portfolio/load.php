<?php

include_once FOTON_CORE_CPT_PATH . '/portfolio/portfolio-register.php';
include_once FOTON_CORE_CPT_PATH . '/portfolio/helper-functions.php';