<?php

include_once FOTON_CORE_ABS_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';