<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/video-button/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/video-button/video-button.php';