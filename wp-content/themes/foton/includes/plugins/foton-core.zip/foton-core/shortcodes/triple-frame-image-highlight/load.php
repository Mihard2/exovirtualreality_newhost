<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/triple-frame-image-highlight/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/triple-frame-image-highlight/triple-frame-image-highlight.php';