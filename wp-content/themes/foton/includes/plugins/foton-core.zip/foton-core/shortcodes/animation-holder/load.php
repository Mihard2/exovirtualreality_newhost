<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/animation-holder/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/animation-holder/animation-holder.php';