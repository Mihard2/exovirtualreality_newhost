<?php

include_once FOTON_CORE_SHORTCODES_PATH.'/horizontal-layer-slider/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH.'/horizontal-layer-slider/horizontal-layer-slider.php';