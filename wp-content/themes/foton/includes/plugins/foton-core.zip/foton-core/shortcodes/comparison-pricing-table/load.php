<?php

include_once FOTON_CORE_SHORTCODES_PATH.'/comparison-pricing-table/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH.'/comparison-pricing-table/cpt-holder.php';
include_once FOTON_CORE_SHORTCODES_PATH.'/comparison-pricing-table/cpt-table.php';