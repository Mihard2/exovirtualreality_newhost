<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/clients-carousel/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/clients-carousel/clients-carousel.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/clients-carousel/clients-carousel-item.php';